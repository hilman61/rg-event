'use client'

import Link from 'next/link'

export default function Footer() {
  return (
    <footer className="w-full bg-black text-gray-400 border-t border-white/10">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">RG</span>
              </div>
              <span className="font-bold text-white">RG EVENT</span>
            </div>
            <p className="text-sm leading-relaxed">
              Solusi acara profesional untuk menciptakan pengalaman yang tak terlupakan.
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="font-semibold text-white">Navigasi</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="#home" className="hover:text-primary transition-colors">Beranda</Link></li>
              <li><Link href="#about" className="hover:text-primary transition-colors">Tentang Kami</Link></li>
              <li><Link href="#services" className="hover:text-primary transition-colors">Layanan</Link></li>
              <li><Link href="#portfolio" className="hover:text-primary transition-colors">Portofolio</Link></li>
            </ul>
          </div>

          {/* Services */}
          <div className="space-y-4">
            <h4 className="font-semibold text-white">Layanan</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="#" className="hover:text-primary transition-colors">Event Organizer</Link></li>
              <li><Link href="#" className="hover:text-primary transition-colors">Show Management</Link></li>
              <li><Link href="#" className="hover:text-primary transition-colors">Corporate Gathering</Link></li>
              <li><Link href="#" className="hover:text-primary transition-colors">Team Building</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div className="space-y-4">
            <h4 className="font-semibold text-white">Kontak</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="tel:+621234567890" className="hover:text-primary transition-colors">+62 (123) 456-7890</a></li>
              <li><a href="mailto:info@rgevent.com" className="hover:text-primary transition-colors">info@rgevent.com</a></li>
              <li>Jakarta, Indonesia</li>
            </ul>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-white/10 py-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm">
              © {new Date().getFullYear()} RG Event Production. Semua hak dilindungi.
            </p>
            <div className="flex gap-6">
              <Link href="#" className="text-sm hover:text-primary transition-colors">Kebijakan Privasi</Link>
              <Link href="#" className="text-sm hover:text-primary transition-colors">Syarat & Ketentuan</Link>
              <Link href="#" className="text-sm hover:text-primary transition-colors">Sitemap</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
