'use client'

export default function Services() {
  const services = [
    {
      id: 1,
      title: 'EVENT ORGANIZER',
      description: 'Kelola acara Anda dengan konsep kreatif dan profesional',
      icon: '🎪'
    },
    {
      id: 2,
      title: 'SHOW MANAGEMENT',
      description: 'Manajemen pertunjukan dengan standar internasional',
      icon: '🎬'
    },
    {
      id: 3,
      title: 'CORPORATE GATHERING',
      description: 'Acara gathering korporat yang berkesan dan produktif',
      icon: '👥'
    },
    {
      id: 4,
      title: 'TEAM BUILDING',
      description: 'Program team building untuk meningkatkan kohesi tim',
      icon: '🤝'
    },
    {
      id: 5,
      title: 'TOUR & TRAVEL',
      description: 'Paket wisata dan perjalanan yang memorable',
      icon: '✈️'
    },
    {
      id: 6,
      title: 'EXHIBITION & EXPO',
      description: 'Pameran dan expo dengan konsep modern dan menarik',
      icon: '🏛️'
    }
  ]

  return (
    <section id="services" className="w-full py-16 md:py-24 bg-black text-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Layanan Kami</h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Berbagai layanan profesional untuk memenuhi kebutuhan event Anda
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => (
            <div
              key={service.id}
              className="group bg-gradient-to-br from-white/5 to-white/0 border border-white/10 rounded-lg p-8 hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/20"
            >
              <div className="text-4xl mb-4">{service.icon}</div>
              <h3 className="text-xl font-bold mb-3 text-primary group-hover:text-primary/90 transition-colors">
                {service.title}
              </h3>
              <p className="text-gray-400 leading-relaxed">
                {service.description}
              </p>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-16">
          <button className="px-8 py-3 bg-primary text-white font-semibold rounded-lg hover:bg-primary/90 transition-colors">
            JELAJAHI SEMUA LAYANAN
          </button>
        </div>
      </div>
    </section>
  )
}
